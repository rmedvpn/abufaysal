var currentlyOpenSidebar = "";
var currentlyOpenSubSidebar = "";
var callerSidebar = "";
var AppNotifyTimer = "";
var AppNotifyStopToken = "";
var boolFlag = false;

function showExternalMenu(caller_id,menu_name) {
    caller_id = caller_id || "";
    if (caller_id == "") {
        controller.close(menu_name);
        currentlyOpenSidebar = '';
    }
    else {
        controller.open(caller_id);
        currentlyOpenSidebar = caller_id;

    }
}

function ControlButton() {
    if (callerSidebar != "") {
        controller.open(callerSidebar);
        currentlyOpenSidebar = callerSidebar;
        switch (sbRefresh) {
            case "WhatEver":
                break;
        }
        callerSidebar = "";
    }
    else {
        switch (currentlyOpenSidebar) {
            case "MahWorld":
                controller.close("MahWorld");
                currentlyOpenSidebar = "";
                break;
            case "MainSb":
                controller.close("MainSb");
                currentlyOpenSidebar = "";
                break;
            case "SubMenu":
                controller.open("MainSb");
                currentlyOpenSidebar = "MainSb";
                clearContent('SubMenuContent');
            case "SubMenuDialog":
                controller.open("SubMenu");
                currentlyOpenSidebar = "SubMenu";
                clearContent('SubMenuDialogContent');



                break;

            case "":
                // controller.open('msngr');
                //   currentlyOpenSidebar = 'msngr';
                break;



        }
    }



}

function AppNotify(n_id, ret_containter, stop_token,ref_rate) {
    n_id = n_id || "";
    ret_containter = ret_containter || "";
    stop_token = stop_token || "";
    ref_rate = ref_rate || 1000;
    AppNotifyStopToken = "start";
    AppNotifyTimer = setInterval(function () { AjaxUpdate("APP_NOTIFY", ret_containter, '', n_id, stop_token); }, ref_rate);

}
function StopAppNotify( stop_token) {
    stop_token = stop_token || "";
    clearInterval(AppNotifyTimer);
}
/////////////
function AjaxActions(field, value,is_refresh,param1,param2,param3,param4) {
        is_refresh = is_refresh || "";
        param1 = param1 || "";
        param2 = param2 || "";
        param3 = param3 || "";
        param4 = param4 || "";
        var theHandler = "/Scripts/AjaxActions";
    console.log(theHandler);

            var formData = new FormData();


        switch (field) 
        {
            case "RegisterProspect":
            case "NickSelect":
            case "PlaceOrder":
            case "ReviewOrder":
            case "ReviewListChange":
            case "SaveNewsLetPref":
            case "ReviewOrderFeedback":
            case "SubmitOrderFeedback":
            case "UpdatePersonalInfo":
            case "JobApp":
            case "ContactForm":
                var form = document.getElementById(param1);
                formData = new FormData(form);
                break;
       }

        formData.append("theAction", field);
        formData.append("field", field);
        formData.append("value", value);
        formData.append("param1", param1);
        formData.append("param2", param2);
        formData.append("param3", param3);
        formData.append("param4", param4);

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var theRes = this.responseText;
                switch (field) {
                    case "PROSPECTMSGSENT":
                        if (callerSidebar == "") { callerSidebar = "MainSb"; }
                        clearContent(currentlyOpenSidebar + "Content");
                        controller.open(callerSidebar);
                        EliminateElement('prospect_' + value);
                        break;

                    case "RegisterProspect":
                    case "NickSelect":
                        if (!theRes.startsWith("!$!")) {
                            showElement('prospectJoinValidationError');
                            console.log('sdfasdfasd123');
                            if (field == "NickSelect") { sbload('MainSb', 'NickSelect - thankyou'); }
                            else { sbload('MainSb', 'Register_thankyou', '', param1); }
                           
                        }
                        else {
                            document.getElementById('prospectJoinValidationError').innerHTML = theRes.replace("!$!", "");
                            showElement('prospectJoinValidationError');
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }
                        
                        break;

                    case "ReviewOrder":
                        if (!theRes.startsWith("!$!")) {
                            hideElement('prospectJoinValidationError');
                            sbload('SubMenu', 'OrderApproval', '', param1);
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }
                        else {
                            document.getElementById('prospectJoinValidationError').innerHTML = theRes.replace("!$!", "");
                            showElement('prospectJoinValidationError');
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }

                        break;


                        
                    case "ReviewOrderFeedback":
                        if (!theRes.startsWith("!$!")) {
                            hideElement('prospectJoinValidationError');
                            sbload('SubMenu', 'OrderFeedbackApproval', '', param1);
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }
                        else {
                            document.getElementById('prospectJoinValidationError').innerHTML = theRes.replace("!$!", "");
                            showElement('prospectJoinValidationError');
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }

                        break;

                    case "PlaceOrder":
                        if (!theRes.startsWith("!$!")) {
                            var order_serial = theRes;
                            //sbload('MainSb', 'OrderThankYou?o_id=' + order_serial);
                            sbload('MainSb', 'OrderThankYou', '', param1);
                        }
                        else {
                            sbload('MainSb', 'OrderFailure', '', param1);
                        }

                        break;

                    case "ReviewListChange":
                        if (!theRes.startsWith("!$!")) {
                            hideElement('prospectJoinValidationError');
                            sbload('SubMenu', 'ListChangeApproval', '', param1);
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }
                        else {
                            document.getElementById('prospectJoinValidationError').innerHTML = theRes.replace("!$!", "");
                            showElement('prospectJoinValidationError');
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }

                        break;

                    case "SaveNewsLetPref":
                        if (!theRes.startsWith("!$!")) {
                            var order_serial = theRes;
                            sbload('MainSb', 'NewsLetterThankYou', '', param1);
                        }
                        else {
                            sbload('MainSb', 'NewsLetterFailure', '', param1);
                        }

                        break;

                    case "SubmitOrderFeedback":
                        if (!theRes.startsWith("!$!")) {
                            var order_serial = theRes;
                            sbload('MainSb', 'OrderFeedbackThankYou', '', param1);
                        }
                        else {
                            sbload('MainSb', 'OrderFeedbackThankYou', '', param1);
                        }

                        break;

                    case "UpdatePersonalInfo":
                  
                        if (!theRes.startsWith("!$!")) {
                            showElement('prospectJoinValidationError');
                            console.log('sdfasdfasd123');
                            if (field == "NickSelect") { sbload('MainSb', 'NickSelect - thankyou'); }
                            else { sbload('MainSb', 'UpdateInfo_thankyou', '', param1); }
                        }
                        else {
                            document.getElementById('prospectJoinValidationError').innerHTML = theRes.replace("!$!", "");
                            showElement('prospectJoinValidationError');
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }

                        break;

                    case "JobApp":
                        if (!theRes.startsWith("!$!")) {
                            showElement('prospectJoinValidationError');
                            console.log('sdfasdfasd123');
                            sbload('MainSb', 'JobApp - thankyou', '', param1);
                        }
                        else {
                            document.getElementById('prospectJoinValidationError').innerHTML = theRes.replace("!$!", "");
                            showElement('prospectJoinValidationError');
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }

                        break;

                    case "ContactForm":
                        if (!theRes.startsWith("!$!")) {
                            showElement('prospectJoinValidationError');
                            console.log('sdfasdfasd123');
                            sbload('MainSb', 'Contact - thankyou', '', param1);
                        }
                        else {
                            document.getElementById('prospectJoinValidationError').innerHTML = theRes.replace("!$!", "");
                            showElement('prospectJoinValidationError');
                            hideElement('prospectJoinLoader');
                            showElement('prospectJoinActions');
                        }

                        break;
                        

                }
                //Notify(theRes.replace("!$!", ""), 1);
            } console.log(this.responseText);

        };
        xmlhttp.open("POST", theHandler, true);
        xmlhttp.send(formData);
    }


function AjaxUpdate(theAction,return_container,loaderElement,param1,param2) {
    loaderElement = loaderElement || "";
    param1 = param1 || "";
    param2 = param2 || "";

    var handlerUrl = "";
    var formData = new FormData();
    var is_loader = true;
    handlerUrl = "Scripts/AjaxHandler";
    if(loaderElement!=""){
        showElement(loaderElement);
    }

    switch(theAction){
        case 'NonActiveReport':
            var form = document.getElementById('NonActiveReport');
            formData = new FormData(form);
            break;

        case "APP_NOTIFY":
            //document.getElementById(return_container).innerHTML = '';
            //alert(param1);

            break;
    }

    formData.append("theAction", theAction);
    formData.append("param1", param1);
    formData.append("param2", param2);


    if(theAction=="ROUNDITEMINFO"){
         formData.append("item_id", param1);
    }
  
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {

                document.getElementById(return_container).innerHTML = this.responseText;
                showElement(return_container);
                if (loaderElement != "") {
                    hideElement(loaderElement);
                }

                switch(theAction)
                {
                    case 'NonActiveReport':
                    if(IsAccordion('ReportSettingsAcc')){Accordionize('ReportSettingsAcc');}
                        break;

                    case "APP_NOTIFY":
                        //Notify(this.responseText);
                        if (AppNotifyStopToken == "") {
                            StopAppNotify('sdf');
                        }
                    
                        break;
                }   

                if (theAction == "ROUNDITEMINFO") {
                    Accordionize('btnAccRounds');
                }


            } console.log(this.responseText);
        };

        xmlhttp.open("POST", handlerUrl, true);
        xmlhttp.send(formData);
    }

function intBehave(theAction,ActionParam) {

    switch (theAction) {

        case "settingsSelector":
            if (ActionParam == 'INFO')
            {
                hideElement('newsPref');
                showElement('infoEdit');
                showElement('prospectJoinActions');
            }
            if (ActionParam == 'ADD' || ActionParam == 'REMOVE') {
                hideElement('infoEdit');
                showElement('newsPref');
                showElement('prospectJoinActions');
            }
            if (ActionParam == '') {
                hideElement('newsPref');
                hideElement('infoEdit');
                hideElement('prospectJoinActions');
            }
            

        break;

    default:
    break;

    }

}

function MiscActions(theAction) {
    theAction = theAction || "";
    console.log(theAction);
    switch (theAction) {
        case "GenerateNick":
            console.log("inside");
            var fname = "";
            var wanum = "";
            var result = "";
            if (document.getElementById("prospect_name")) {
                fname = document.getElementById("prospect_name").value;
                fname = fname.split(" ");
                fname = fname[0];


            }
            if (document.getElementById("wanum")) {
                wanum = document.getElementById("wanum").value;
                wanum = wanum.slice(-3);

            }

            if (fname != "" && wanum != "") {
                result = fname + wanum;
                console.log(result);
                if (document.getElementById("requested_nick")) {
                    document.getElementById("requested_nick").value = result;
                }
            }
            else {
                if (document.getElementById("requested_nick")) {
                    document.getElementById("requested_nick").value = "";
                }
            }

            break;
 
        case "OrderNewMember":

            hideElement('OrderFormNick');
            showElement('OrderFormFullName');
            hideElement('OrderFormOrderPw');
            showElement('OrderFormNewMember');
            hideElement('OrderFormShipToOther');
            break;
        case "OrderExistingMember":

            hideElement('OrderFormFullName'); 
            showElement('OrderFormNick');
            hideElement('OrderFormNewMember');
            showElement('OrderFormOrderPw');
            showElement('OrderFormShipToOther');
            break;
        case "":
            // controller.open('msngr');
            //   currentlyOpenSidebar = 'msngr';
            break;



    }



}

function PageLoad(thePage) {
    thePage = thePage || "";
    console.log("start");
    console.log(thePage);
    switch (thePage) {
        case "ORDER":
        case "ORDERS":
            sbload('MainSb', 'order');

            break;
        case "ORDERENGLISH":
        case "ORDERSENGLISH":
            sbload('MainSb', 'orderEng');

            break;
        case "FEEDBACK":
            sbload('MainSb', 'OrderFeedback');

            break;
        case "FEEDBACKENGLISH":
            sbload('MainSb', 'OrderFeedbackEng');

            break;
        case "JOB":
        case "JOBS":
            sbload('MainSb', 'JobApp');

            break;
        default:
            // controller.open('msngr');
            //   currentlyOpenSidebar = 'msngr';
            break;



    }



}
